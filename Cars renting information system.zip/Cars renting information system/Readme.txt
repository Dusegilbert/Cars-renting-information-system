How to run Project
1. Download and Unzip the file.
2. Put Cars renting information system folder inside root directory 
   (for xampp xampp/htdocs)

Database Configuration
----------------------
Open phpmyadmin
Create Database "car_rental"
Import database car_rental.sql (available SQL File Folder inside zip package)

This project containes  PHP with OOP and Mysql

Open Your browser put inside browser 
“http://localhost/Cars renting information system/carRental/index.php”

but you will find to forms for login and signup then select your role 
if you are admin use information of admin you have given below 
if you  are not it means you are client 
so you have to use client information you have given below
but as role of admin you can create new client who is able to login,view cars and logout.

For Admin(admin will be able to make login, register cars, delete and update cars and logout) 
---------
Login Details for admin :
Username: admin
Password: admin123

For client(client will be  able to make login,view cars and  logout)
----------
Login Details for user:
Username : dusenge
Password: dusenge123

