<?php
require_once 'car.php';

if (isset($_POST['add'])) {
    $make = $_POST['make'];
    $model = $_POST['model'];
     $year = $_POST['year'];
    $price = $_POST['price'];

    $car = new Car();
    $car->addCar($make, $model, $year, $price);

    header('Location: admin.php');
}
?>
