<?php
require_once 'database.php';

class Car
{
    private $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    public function getAllCars()
    {
        $sql = "SELECT * FROM cars";
        $result = $this->db->query($sql);

        $cars = [];

        while ($row = $this->db->fetchArray($result)) {
            $cars[] = $row;
        }

        return $cars;
    }

    public function addCar($make, $model, $year, $price)
    {
        $sql = "INSERT INTO cars (make, model, year, price) VALUES ('$make', '$model', '$year', '$price')";
        $result = $this->db->query($sql);

        return $result;
    }

    public function getCarById($carId)
    {
        $sql = "SELECT * FROM cars WHERE id = '$carId'";
        $result = $this->db->query($sql);

        return $this->db->fetchArray($result);
    }

    public function updateCar($carId, $make, $model, $year, $price)
    {
        $sql = "UPDATE cars SET make = '$make', model = '$model', year = '$year', price = '$price' WHERE id = '$carId'";
        $result = $this->db->query($sql);

        return $result;
    }

    public function deleteCar($carId)
    {
        $sql = "DELETE FROM cars WHERE id = '$carId'";
        $result = $this->db->query($sql);

        return $result;
    }
}
?>
