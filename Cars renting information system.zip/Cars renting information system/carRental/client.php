<!DOCTYPE html>
<html>
<head>
    <title>Car Rental System - Client Panel</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Welcome, Client!</h2>
        <a href="logout.php" class="logout">Logout</a>
        <h3>Car Inventory</h3>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Make</th>
                    <th>Model</th>
                    <th>Year</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                <?php
                require_once 'car.php';

                $car = new Car();
                $cars = $car->getAllCars();

                foreach ($cars as $car) {
                    echo '<tr>';
                    echo '<td>' . $car['id'] . '</td>';
                    echo '<td>' . $car['make'] . '</td>';
                    echo '<td>' . $car['model'] . '</td>';
                    echo '<td>' . $car['year'] . '</td>';
                    echo '<td>' . $car['price'] . '</td>';
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
