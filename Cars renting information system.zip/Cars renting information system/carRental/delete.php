<?php
require_once 'car.php';

if (isset($_GET['id'])) {
    $carId = $_GET['id'];

    $car = new Car();
    $car->deleteCar($carId);

    header('Location: admin.php');
}
?>
