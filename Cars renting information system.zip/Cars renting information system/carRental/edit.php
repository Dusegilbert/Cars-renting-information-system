<?php
require_once 'car.php';

if (isset($_GET['id'])) {
    $carId = $_GET['id'];

    $car = new Car();
    $carDetails = $car->getCarById($carId);

    if ($carDetails) {
        $make = $carDetails['make'];
        $model = $carDetails['model'];
        $year = $carDetails['year'];
        $price = $carDetails['price'];
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Car Rental System - Edit Car</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Edit Car</h2>
        <form method="post" action="update.php">
            <input type="hidden" name="id" value="<?php echo $carId; ?>">
            <div class="form-group">
                <label for="make">Make</label>
                <input type="text" name="make" value="<?php echo $make; ?>" required>
            </div>
            <div class="form-group">
                <label for="model">Model</label>
                <input type="text" name="model" value="<?php echo $model; ?>" required>
            </div>
            <div class="form-group">
                <label for="year">Year</label>
                <input type="number" name="year" value="<?php echo $year; ?>" required>
            </div>
            <div class="form-group">
                <label for="price">Price</label>
                <input type="number" step="0.01" name="price" value="<?php echo $price; ?>" required>
            </div>
            <button type="submit" name="update">Update Car</button>
        </form>
    </div>
</body>
</html>
