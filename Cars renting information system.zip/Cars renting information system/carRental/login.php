<?php
session_start();

require_once 'user.php';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $user = new User();
    $loginResult = $user->login($username, $password);

    if ($loginResult) {
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $loginResult['role'];

        if ($loginResult['role'] === 'admin') {
            header('Location: admin.php');
        } elseif ($loginResult['role'] === 'client') {
            header('Location: client.php');
        }
    } else {
        echo 'Invalid username or password.';
    }
}
?>
