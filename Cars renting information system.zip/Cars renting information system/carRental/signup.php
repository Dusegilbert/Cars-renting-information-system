<?php
require_once 'user.php';

if (isset($_POST['signup'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    $user = new User();
    $signupResult = $user->signup($username, $password, $role);

    if ($signupResult) {
        echo 'Signup successful. Please login.';
    } else {
        echo 'Signup failed. Please try again.';
    }
}
?>
