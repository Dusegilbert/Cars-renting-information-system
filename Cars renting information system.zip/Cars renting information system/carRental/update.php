<?php
require_once 'car.php';

if (isset($_POST['update'])) {
    $carId = $_POST['id'];
    $make = $_POST['make'];
    $model = $_POST['model'];
    $year = $_POST['year'];
    $price = $_POST['price'];

    $car = new Car();
    $car->updateCar($carId, $make, $model, $year, $price);

    header('Location: admin.php');
}
?>
