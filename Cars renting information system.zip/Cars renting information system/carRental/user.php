<?php
require_once 'database.php';

class User
{
    private $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    public function login($username, $password)
    {
        $hashedPassword = md5($password); // Note: This is a simple example, use better password hashing in a real system

        $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$hashedPassword'";
        $result = $this->db->query($sql);

        if ($this->db->numRows($result) == 1) {
            return $this->db->fetchArray($result);
        }

        return false;
    }

    public function signup($username, $password, $role)
    {
        $hashedPassword = md5($password); // Note: This is a simple example, use better password hashing in a real system

        $sql = "INSERT INTO users (username, password, role) VALUES ('$username', '$hashedPassword', '$role')";
        $result = $this->db->query($sql);

        return $result;
    }
}
?>
